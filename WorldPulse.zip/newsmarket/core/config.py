"""
All the settings you are likely to change live in this one file:
news sources, market tickers, and the keyword rules that link news to markets.
"""

APP_NAME = "WorldPulse"
DISPLAY_TIMEZONE = "Asia/Kolkata"      # times in the app are shown in this zone
REFRESH_MINUTES = 3                    # news is re-fetched from all sources at most every 3 minutes
PRICE_REFRESH_SECONDS = 60             # market prices refresh every minute
AUTO_REFRESH_SECONDS = 60              # open pages check for new stories this often
DEFAULT_CLAUDE_MODEL = "claude-haiku-4-5-20251001"   # cheap + fast; change to "claude-sonnet-5-5" for deeper analysis

# ---------------------------------------------------------------------------
# NEWS SOURCES  (public RSS feeds – free, no key needed)
# region: where the story is mostly about / published
# category: World, Business, Markets, Tech, Politics
# You can add more from inside the app (Sources page) without touching code.
# ---------------------------------------------------------------------------
def _gn(topic: str, hl: str, gl: str) -> str:
    return f"https://news.google.com/rss/headlines/section/topic/{topic}?hl={hl}&gl={gl}&ceid={gl}:{hl.split('-')[0]}"

def _gns(query: str, hl: str, gl: str) -> str:
    q = query.replace(" ", "+")
    return f"https://news.google.com/rss/search?q={q}&hl={hl}&gl={gl}&ceid={gl}:{hl.split('-')[0]}"

SOURCES = [
    # --- Google News editions: one feed pulls from thousands of publishers per country ---
    {"name": "Google News · World (US edition)", "url": _gn("WORLD", "en-US", "US"), "region": "Global", "category": "World"},
    {"name": "Google News · Business (US)", "url": _gn("BUSINESS", "en-US", "US"), "region": "United States", "category": "Business"},
    {"name": "Google News · Business (India)", "url": _gn("BUSINESS", "en-IN", "IN"), "region": "India", "category": "Business"},
    {"name": "Google News · World (India)", "url": _gn("WORLD", "en-IN", "IN"), "region": "Global", "category": "World"},
    {"name": "Google News · Business (UK)", "url": _gn("BUSINESS", "en-GB", "GB"), "region": "Europe", "category": "Business"},
    {"name": "Google News · Business (Singapore)", "url": _gn("BUSINESS", "en-SG", "SG"), "region": "Asia", "category": "Business"},
    {"name": "Google News · Business (Australia)", "url": _gn("BUSINESS", "en-AU", "AU"), "region": "Asia", "category": "Business"},
    {"name": "Google News · Technology (US)", "url": _gn("TECHNOLOGY", "en-US", "US"), "region": "Global", "category": "Tech"},
    {"name": "Google News · Stock market (India)", "url": _gns("stock market Sensex Nifty", "en-IN", "IN"), "region": "India", "category": "Markets"},
    {"name": "Google News · Wall Street", "url": _gns("Wall Street stocks", "en-US", "US"), "region": "United States", "category": "Markets"},
    {"name": "Google News · China economy", "url": _gns("China economy markets", "en-US", "US"), "region": "China", "category": "Markets"},
    {"name": "Google News · Japan markets", "url": _gns("Nikkei Japan markets", "en-US", "US"), "region": "Japan", "category": "Markets"},
    {"name": "Google News · Europe markets", "url": _gns("European stocks ECB", "en-GB", "GB"), "region": "Europe", "category": "Markets"},
    {"name": "Google News · Middle East", "url": _gns("Middle East oil Gulf", "en-US", "US"), "region": "Middle East", "category": "World"},
    {"name": "Google News · Commodities", "url": _gns("crude oil gold prices", "en-US", "US"), "region": "Global", "category": "Markets"},
    # --- Direct publisher feeds ---
    {"name": "BBC World", "url": "https://feeds.bbci.co.uk/news/world/rss.xml", "region": "Global", "category": "World"},
    {"name": "BBC Business", "url": "https://feeds.bbci.co.uk/news/business/rss.xml", "region": "Europe", "category": "Business"},
    {"name": "Al Jazeera", "url": "https://www.aljazeera.com/xml/rss/all.xml", "region": "Middle East", "category": "World"},
    {"name": "The Guardian · World", "url": "https://www.theguardian.com/world/rss", "region": "Global", "category": "World"},
    {"name": "The Guardian · Business", "url": "https://www.theguardian.com/business/rss", "region": "Europe", "category": "Business"},
    {"name": "DW (Germany)", "url": "https://rss.dw.com/rdf/rss-en-all", "region": "Europe", "category": "World"},
    {"name": "France 24", "url": "https://www.france24.com/en/rss", "region": "Europe", "category": "World"},
    {"name": "NYT · Business", "url": "https://rss.nytimes.com/services/xml/rss/nyt/Business.xml", "region": "United States", "category": "Business"},
    {"name": "NYT · World", "url": "https://rss.nytimes.com/services/xml/rss/nyt/World.xml", "region": "Global", "category": "World"},
    {"name": "CNBC · World", "url": "https://www.cnbc.com/id/100727362/device/rss/rss.html", "region": "Global", "category": "Markets"},
    {"name": "CNBC · Top news", "url": "https://www.cnbc.com/id/100003114/device/rss/rss.html", "region": "United States", "category": "Markets"},
    {"name": "Economic Times · Markets", "url": "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms", "region": "India", "category": "Markets"},
    {"name": "Livemint · Markets", "url": "https://www.livemint.com/rss/markets", "region": "India", "category": "Markets"},
    {"name": "Business Standard · Markets", "url": "https://www.business-standard.com/rss/markets-106.rss", "region": "India", "category": "Markets"},
    {"name": "Moneycontrol · Latest", "url": "https://www.moneycontrol.com/rss/latestnews.xml", "region": "India", "category": "Markets"},
]

REGIONS = ["Global", "United States", "India", "China", "Japan", "Europe", "Asia", "Middle East"]
CATEGORIES = ["World", "Business", "Markets", "Tech", "Politics"]

# ---------------------------------------------------------------------------
# MARKETS  (Yahoo Finance tickers – free via the yfinance library)
# ---------------------------------------------------------------------------
INDICES = {
    # name: (ticker, region)
    "S&P 500": ("^GSPC", "United States"),
    "Nasdaq": ("^IXIC", "United States"),
    "Dow Jones": ("^DJI", "United States"),
    "Nifty 50": ("^NSEI", "India"),
    "Sensex": ("^BSESN", "India"),
    "Bank Nifty": ("^NSEBANK", "India"),
    "FTSE 100": ("^FTSE", "Europe"),
    "DAX": ("^GDAXI", "Europe"),
    "CAC 40": ("^FCHI", "Europe"),
    "Euro Stoxx 50": ("^STOXX50E", "Europe"),
    "Nikkei 225": ("^N225", "Japan"),
    "Hang Seng": ("^HSI", "China"),
    "Shanghai": ("000001.SS", "China"),
    "KOSPI": ("^KS11", "Asia"),
    "ASX 200": ("^AXJO", "Asia"),
    "Tadawul (Saudi)": ("^TASI.SR", "Middle East"),
}
COMMODITIES_FX = {
    "Brent crude": ("BZ=F", "Global"),
    "WTI crude": ("CL=F", "Global"),
    "Gold": ("GC=F", "Global"),
    "Silver": ("SI=F", "Global"),
    "US 10Y yield": ("^TNX", "United States"),
    "USD/INR": ("INR=X", "India"),
    "EUR/USD": ("EURUSD=X", "Europe"),
    "USD/JPY": ("JPY=X", "Japan"),
    "USD/CNY": ("CNY=X", "China"),
    "Bitcoin": ("BTC-USD", "Global"),
}
# Main index used for the "market reaction" chart of each region
REGION_MAIN_INDEX = {
    "United States": "S&P 500", "India": "Nifty 50", "Europe": "Euro Stoxx 50", "Japan": "Nikkei 225",
    "China": "Hang Seng", "Asia": "KOSPI", "Middle East": "Tadawul (Saudi)", "Global": "S&P 500",
}

# ---------------------------------------------------------------------------
# WHICH COUNTRY / REGION IS A STORY ABOUT?  (keyword → region)
# ---------------------------------------------------------------------------
REGION_KEYWORDS = {
    "United States": ["u.s.", "america", "american", "washington", "wall street", "fed ", "federal reserve",
                      "powell", "white house", "trump", "treasury", "nasdaq", "s&p", "dow"],
    "India": ["india", "indian", "rbi", "sensex", "nifty", "modi", "delhi", "mumbai", "rupee", "sebi", "nse", "bse"],
    "China": ["china", "chinese", "beijing", "yuan", "pboc", "xi jinping", "hong kong", "shanghai", "hang seng"],
    "Japan": ["japan", "japanese", "tokyo", "boj", "bank of japan", "yen", "nikkei"],
    "Europe": ["europe", "european", "ecb", "eurozone", "euro ", "germany", "german", "france", "french", "uk ",
               "britain", "british", "bank of england", "london", "brussels", "eu ", "italy", "spain"],
    "Asia": ["korea", "seoul", "taiwan", "singapore", "australia", "indonesia", "vietnam", "asia", "asean"],
    "Middle East": ["iran", "israel", "saudi", "opec", "gulf", "uae", "dubai", "qatar", "iraq", "gaza", "red sea", "yemen"],
}

# ---------------------------------------------------------------------------
# NEWS → SECTOR RULES
# Each rule: keywords that trigger it, and the likely effect on sectors.
# effect: +1 = usually positive, -1 = usually negative, 0 = watch (depends on direction)
# These are simple, transparent rules – "indicative", not advice.
# ---------------------------------------------------------------------------
SECTOR_RULES = [
    {"name": "Oil price", "keywords": ["crude", "oil price", "brent", "opec", "oil supply", "barrel"],
     "sectors": {"Energy / Oil & Gas": 0, "Airlines": 0, "Paints & Chemicals": 0, "Oil marketing (OMCs)": 0}},
    {"name": "Interest rates", "keywords": ["rate cut", "rate hike", "interest rate", "repo rate", "fed ", "federal reserve",
                                             "ecb", "rbi", "bank of japan", "monetary policy", "inflation"],
     "sectors": {"Banks & Financials": 0, "Real estate": 0, "Auto": 0, "Bonds": 0}},
    {"name": "Trade & tariffs", "keywords": ["tariff", "trade war", "export", "import duty", "trade deal", "sanction"],
     "sectors": {"Exporters / IT": 0, "Auto": 0, "Metals": 0, "Manufacturing": 0}},
    {"name": "Geopolitical risk", "keywords": ["war", "attack", "missile", "conflict", "invasion", "strike on", "military", "ceasefire"],
     "sectors": {"Defence": 1, "Gold": 1, "Energy / Oil & Gas": 1, "Airlines": -1, "Broad market": -1}},
    {"name": "Tech & AI", "keywords": ["ai ", "artificial intelligence", "chip", "semiconductor", "nvidia", "data center", "software"],
     "sectors": {"Technology": 0, "Semiconductors": 0, "IT services": 0}},
    {"name": "Currency", "keywords": ["rupee", "dollar index", "yen", "yuan", "euro ", "currency", "forex"],
     "sectors": {"Exporters / IT": 0, "Importers": 0}},
    {"name": "Gold & metals", "keywords": ["gold", "silver", "copper", "steel", "aluminium", "aluminum", "metal"],
     "sectors": {"Metals & Mining": 0, "Gold": 0, "Jewellery": 0}},
    {"name": "Earnings", "keywords": ["earnings", "quarterly results", "profit", "revenue", "q1 ", "q2 ", "q3 ", "q4 ", "guidance"],
     "sectors": {"Company-specific": 0}},
    {"name": "Banking & credit", "keywords": ["bank", "loan", "npa", "credit", "default", "bond yield", "debt"],
     "sectors": {"Banks & Financials": 0}},
    {"name": "Auto & EV", "keywords": ["car sales", "auto sales", "electric vehicle", " ev ", "tesla", "automaker"],
     "sectors": {"Auto": 0, "Batteries": 0}},
    {"name": "Pharma & health", "keywords": ["pharma", "drug", "fda", "vaccine", "usfda", "healthcare"],
     "sectors": {"Pharma": 0}},
    {"name": "Government & budget", "keywords": ["budget", "fiscal", "gst", "tax cut", "stimulus", "subsidy", "election"],
     "sectors": {"Broad market": 0, "Infrastructure": 0}},
    {"name": "Crypto", "keywords": ["bitcoin", "crypto", "ethereum", "stablecoin"],
     "sectors": {"Crypto": 0}},
]

# Words that tilt the direction of a story (for equity markets)
POSITIVE_WORDS = ["surge", "soar", "rally", "jump", "gain", "record high", "beat", "rate cut", "cuts rates", "stimulus",
                  "deal", "ceasefire", "upgrade", "boost", "rebound", "strong", "growth", "eases", "cools", "approval"]
NEGATIVE_WORDS = ["plunge", "slump", "crash", "fall", "drop", "tumble", "miss", "rate hike", "raises rates", "recession",
                  "war", "attack", "sanction", "tariff", "downgrade", "default", "layoff", "inflation rises", "selloff",
                  "sell-off", "fear", "crisis", "probe", "ban", "weak", "slowdown", "shutdown"]

# Rule-specific direction hints: if the story says X, the sector move is Y.
DIRECTION_HINTS = {
    "Oil price": {"up": ["rise", "jump", "surge", "spike", "cut output", "supply cut"],
                  "down": ["fall", "drop", "slump", "slip", "output hike", "boost supplies", "ease"],
                  "if_up": {"Energy / Oil & Gas": 1, "Airlines": -1, "Paints & Chemicals": -1, "Oil marketing (OMCs)": -1},
                  "if_down": {"Energy / Oil & Gas": -1, "Airlines": 1, "Paints & Chemicals": 1, "Oil marketing (OMCs)": 1}},
    "Interest rates": {"up": ["hike", "raise", "hawkish", "inflation rises", "higher for longer"],
                       "down": ["cut", "dovish", "ease", "inflation cools", "inflation eases"],
                       "if_up": {"Banks & Financials": 0, "Real estate": -1, "Auto": -1, "Bonds": -1},
                       "if_down": {"Banks & Financials": 1, "Real estate": 1, "Auto": 1, "Bonds": 1}},
    "Trade & tariffs": {"up": ["tariff", "trade war", "sanction", "ban"], "down": ["trade deal", "lift", "ease", "truce"],
                        "if_up": {"Exporters / IT": -1, "Auto": -1, "Metals": -1, "Manufacturing": -1},
                        "if_down": {"Exporters / IT": 1, "Auto": 1, "Metals": 1, "Manufacturing": 1}},
}

# Themes that also point at a specific asset in the "How the market reacted" chart
THEME_ASSETS = {
    "Oil price": ["Brent crude"],
    "Gold & metals": ["Gold"],
    "Currency": ["USD/INR"],
    "Crypto": ["Bitcoin"],
    "Interest rates": ["US 10Y yield"],
}
