"""Fetch the full text of a story for the in-app reader (for personal reading; always link back to the publisher)."""
from __future__ import annotations

import requests

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"


def full_text(url: str, timeout: int = 15) -> str | None:
    try:
        import trafilatura
        r = requests.get(url, headers={"User-Agent": UA}, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
        text = trafilatura.extract(r.text, include_comments=False, include_tables=False, favor_precision=True)
        if text and len(text) > 300:
            return text
        return None
    except Exception:
        return None
