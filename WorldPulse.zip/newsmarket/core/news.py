"""Fetch news from many RSS feeds at once, clean it, and merge duplicate stories."""
from __future__ import annotations

import hashlib
import html
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

import feedparser
import requests

UA = "Mozilla/5.0 (compatible; WorldPulse/1.0; personal news reader)"
STOP = set("""a an the of to in on for and or with at by from as is are be was were has have had will would can could
after before over into about amid says say said new more than its it this that what why how who live latest update""".split())


def _clean(text: str) -> str:
    text = html.unescape(re.sub(r"<[^>]+>", " ", text or ""))
    return re.sub(r"\s+", " ", text).strip()


def _when(entry) -> datetime | None:
    for k in ("published_parsed", "updated_parsed"):
        t = entry.get(k)
        if t:
            return datetime(*t[:6], tzinfo=timezone.utc)
    for k in ("published", "updated"):
        if entry.get(k):
            try:
                d = parsedate_to_datetime(entry[k])
                return d.astimezone(timezone.utc) if d.tzinfo else d.replace(tzinfo=timezone.utc)
            except Exception:
                pass
    return None


def story_key(title: str) -> str:
    """Words that identify a story, so the same news from 5 outlets merges into one."""
    words = [w for w in re.findall(r"[a-z0-9]+", title.lower()) if w not in STOP and len(w) > 2]
    return " ".join(sorted(set(words))[:8])


def parse_feed(raw: bytes | str, source: dict) -> list[dict]:
    """Turn one RSS/Atom document into clean article dicts."""
    feed = feedparser.parse(raw)
    out = []
    for e in feed.entries:
        title = _clean(e.get("title", ""))
        link = e.get("link", "")
        if not title or not link:
            continue
        publisher = source["name"]
        # Google News titles look like "Headline - Publisher"
        if "news.google.com" in source["url"] and " - " in title:
            title, publisher = title.rsplit(" - ", 1)
            publisher = f"{publisher.strip()} (via Google News)"
        summary = _clean(e.get("summary", "") or e.get("description", ""))
        if summary.startswith(title[:40]):  # Google News repeats the title in the summary
            summary = ""
        out.append({
            "id": hashlib.sha1(link.encode()).hexdigest()[:16],
            "title": title.strip(),
            "link": link,
            "publisher": publisher,
            "feed": source["name"],
            "summary": summary[:600],
            "published": (_when(e) or datetime.now(timezone.utc)).isoformat(),
            "region": source.get("region", "Global"),
            "category": source.get("category", "World"),
        })
    return out


def fetch_source(source: dict, timeout: int = 12) -> tuple[list[dict], str | None]:
    try:
        r = requests.get(source["url"], headers={"User-Agent": UA}, timeout=timeout)
        r.raise_for_status()
        items = parse_feed(r.content, source)
        return items, None if items else "No stories in feed"
    except Exception as exc:  # network errors, 404s, bad XML …
        return [], f"{type(exc).__name__}: {str(exc)[:120]}"


def fetch_all(sources: list[dict], workers: int = 16, fetcher=fetch_source) -> tuple[list[dict], dict]:
    """Fetch every enabled source in parallel. Returns (articles, health per source)."""
    articles, health = [], {}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futs = {pool.submit(fetcher, s): s for s in sources}
        for f in as_completed(futs):
            s = futs[f]
            items, err = f.result()
            health[s["name"]] = {"ok": err is None, "count": len(items), "error": err, "url": s["url"]}
            articles.extend(items)
    return merge_duplicates(articles), health


def merge_duplicates(articles: list[dict]) -> list[dict]:
    """Same story from several outlets → one item with 'also_in' list (more outlets = bigger story)."""
    groups: dict[str, dict] = {}
    by_id: set[str] = set()
    for a in sorted(articles, key=lambda x: x["published"]):
        if a["id"] in by_id:
            continue
        by_id.add(a["id"])
        k = story_key(a["title"])
        if not k:
            k = a["id"]
        if k in groups:
            g = groups[k]
            if a["publisher"] not in g["also_in"] and a["publisher"] != g["publisher"]:
                g["also_in"].append(a["publisher"])
            if not g["summary"] and a["summary"]:
                g["summary"] = a["summary"]
        else:
            a = dict(a)
            a["also_in"] = []
            groups[k] = a
    return sorted(groups.values(), key=lambda x: x["published"], reverse=True)
