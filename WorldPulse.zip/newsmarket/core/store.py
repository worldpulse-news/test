"""Your personal data: what you read, what you track, topics you follow, settings. Stored in a local SQLite file."""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timezone

DB_PATH = os.environ.get("WORLDPULSE_DB", os.path.join(os.path.dirname(__file__), "..", "data", "worldpulse.db"))


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Store:
    def __init__(self, path: str = DB_PATH):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS articles (id TEXT PRIMARY KEY, data TEXT, first_seen TEXT);
        CREATE TABLE IF NOT EXISTS reads (id TEXT PRIMARY KEY, read_at TEXT);
        CREATE TABLE IF NOT EXISTS tracked (id TEXT PRIMARY KEY, added_at TEXT, note TEXT DEFAULT '', status TEXT DEFAULT 'Following');
        CREATE TABLE IF NOT EXISTS topics (keyword TEXT PRIMARY KEY, added_at TEXT, last_seen TEXT);
        CREATE TABLE IF NOT EXISTS fulltext (id TEXT PRIMARY KEY, text TEXT, fetched_at TEXT);
        CREATE TABLE IF NOT EXISTS analysis (id TEXT PRIMARY KEY, data TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT);
        """)
        self.db.commit()

    # --- articles (kept so tracked stories survive after they drop out of the feeds) ---
    def save_articles(self, arts: list[dict]):
        self.db.executemany("INSERT OR IGNORE INTO articles VALUES (?,?,?)", [(a["id"], json.dumps(a), now()) for a in arts])
        self.db.commit()

    def article(self, aid: str) -> dict | None:
        r = self.db.execute("SELECT data FROM articles WHERE id=?", (aid,)).fetchone()
        return json.loads(r[0]) if r else None

    def articles(self, ids: list[str]) -> list[dict]:
        out = [self.article(i) for i in ids]
        return [a for a in out if a]

    def search_saved(self, keyword: str, since_iso: str | None = None, limit: int = 200) -> list[dict]:
        q, args = "SELECT data FROM articles WHERE lower(data) LIKE ?", [f"%{keyword.lower()}%"]
        if since_iso:
            q += " AND first_seen > ?"
            args.append(since_iso)
        rows = self.db.execute(q + " ORDER BY first_seen DESC LIMIT ?", (*args, limit)).fetchall()
        return [json.loads(r[0]) for r in rows]

    # --- reading ---
    def mark_read(self, aid: str):
        self.db.execute("INSERT OR REPLACE INTO reads VALUES (?,?)", (aid, now())); self.db.commit()

    def mark_unread(self, aid: str):
        self.db.execute("DELETE FROM reads WHERE id=?", (aid,)); self.db.commit()

    def read_ids(self) -> set[str]:
        return {r[0] for r in self.db.execute("SELECT id FROM reads")}

    def history(self, limit: int = 100) -> list[tuple[str, str]]:
        return self.db.execute("SELECT id, read_at FROM reads ORDER BY read_at DESC LIMIT ?", (limit,)).fetchall()

    # --- tracking ---
    def track(self, aid: str):
        self.db.execute("INSERT OR IGNORE INTO tracked (id, added_at) VALUES (?,?)", (aid, now())); self.db.commit()

    def untrack(self, aid: str):
        self.db.execute("DELETE FROM tracked WHERE id=?", (aid,)); self.db.commit()

    def tracked(self) -> list[dict]:
        rows = self.db.execute("SELECT id, added_at, note, status FROM tracked ORDER BY added_at DESC").fetchall()
        return [{"id": r[0], "added_at": r[1], "note": r[2] or "", "status": r[3]} for r in rows]

    def tracked_ids(self) -> set[str]:
        return {r[0] for r in self.db.execute("SELECT id FROM tracked")}

    def update_tracked(self, aid: str, note: str | None = None, status: str | None = None):
        if note is not None:
            self.db.execute("UPDATE tracked SET note=? WHERE id=?", (note, aid))
        if status is not None:
            self.db.execute("UPDATE tracked SET status=? WHERE id=?", (status, aid))
        self.db.commit()

    # --- topics you follow ---
    def add_topic(self, kw: str):
        kw = kw.strip()
        if kw:
            self.db.execute("INSERT OR IGNORE INTO topics VALUES (?,?,?)", (kw, now(), now())); self.db.commit()

    def remove_topic(self, kw: str):
        self.db.execute("DELETE FROM topics WHERE keyword=?", (kw,)); self.db.commit()

    def topics(self) -> list[dict]:
        return [{"keyword": r[0], "added_at": r[1], "last_seen": r[2]}
                for r in self.db.execute("SELECT keyword, added_at, last_seen FROM topics ORDER BY keyword")]

    def topic_seen(self, kw: str):
        self.db.execute("UPDATE topics SET last_seen=? WHERE keyword=?", (now(), kw)); self.db.commit()

    # --- caches ---
    def get_fulltext(self, aid):
        r = self.db.execute("SELECT text FROM fulltext WHERE id=?", (aid,)).fetchone()
        return r[0] if r else None

    def set_fulltext(self, aid, text):
        self.db.execute("INSERT OR REPLACE INTO fulltext VALUES (?,?,?)", (aid, text, now())); self.db.commit()

    def get_analysis(self, aid):
        r = self.db.execute("SELECT data FROM analysis WHERE id=?", (aid,)).fetchone()
        return json.loads(r[0]) if r else None

    def set_analysis(self, aid, data):
        self.db.execute("INSERT OR REPLACE INTO analysis VALUES (?,?,?)", (aid, json.dumps(data), now())); self.db.commit()

    # --- settings ---
    def get(self, k, default=None):
        r = self.db.execute("SELECT v FROM settings WHERE k=?", (k,)).fetchone()
        return json.loads(r[0]) if r else default

    def set(self, k, v):
        self.db.execute("INSERT OR REPLACE INTO settings VALUES (?,?)", (k, json.dumps(v))); self.db.commit()
