"""Market prices from Yahoo Finance (free, via yfinance). Prices can be delayed ~15 minutes."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pandas as pd


def _history(ticker: str, period: str, interval: str) -> pd.DataFrame:
    import yfinance as yf
    df = yf.Ticker(ticker).history(period=period, interval=interval, auto_adjust=False)
    if df is None or df.empty:
        return pd.DataFrame()
    df = df[["Close"]].dropna()
    idx = df.index
    df.index = idx.tz_convert("UTC") if idx.tz is not None else idx.tz_localize("UTC")
    return df


def quote(ticker: str, history=_history) -> dict | None:
    """Last price, % change vs previous close, and a 1-month sparkline."""
    try:
        d = history(ticker, "1mo", "1d")
        if d.empty:
            return None
        closes = d["Close"].tolist()
        last = closes[-1]
        intra = history(ticker, "1d", "5m")
        if not intra.empty:
            last = float(intra["Close"].iloc[-1])
            prev = closes[-2] if len(closes) >= 2 and d.index[-1].date() == intra.index[-1].date() else closes[-1]
        else:
            prev = closes[-2] if len(closes) >= 2 else closes[-1]
        chg = (last / prev - 1) * 100 if prev else 0.0
        return {"ticker": ticker, "last": float(last), "prev": float(prev), "change_pct": float(chg),
                "spark": [float(x) for x in closes[-22:]], "as_of": (intra.index[-1] if not intra.empty else d.index[-1]).isoformat()}
    except Exception:
        return None


def intraday(ticker: str, history=_history) -> pd.DataFrame:
    """Last 5 trading days at 15-minute steps – used for the news-reaction chart."""
    try:
        return history(ticker, "5d", "15m")
    except Exception:
        return pd.DataFrame()


def reaction(df: pd.DataFrame, published_iso: str, window_min: int = 120) -> dict | None:
    """How did the market move from the moment a story came out?"""
    if df is None or df.empty:
        return None
    t = pd.Timestamp(published_iso)
    t = t.tz_convert("UTC") if t.tzinfo else t.tz_localize("UTC")
    before = df[df.index <= t]
    if before.empty:
        return None
    start_px, start_t = float(before["Close"].iloc[-1]), before.index[-1]
    after = df[(df.index > t) & (df.index <= t + pd.Timedelta(minutes=window_min))]
    latest_px = float(df["Close"].iloc[-1])
    res = {"start_time": start_t.isoformat(), "start_price": start_px,
           "since_pct": (latest_px / start_px - 1) * 100, "latest_time": df.index[-1].isoformat()}
    if not after.empty:
        res["window_pct"] = (float(after["Close"].iloc[-1]) / start_px - 1) * 100
        res["window_min"] = window_min
    if (t - start_t) > pd.Timedelta(hours=3):
        res["note"] = "Market was closed when this was published – move shown from the last close."
    return res
