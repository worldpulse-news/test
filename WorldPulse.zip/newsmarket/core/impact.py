"""
Link a news story to markets.

1. Rule-based (always on, free): finds the countries, markets and sectors a story touches
   and whether the tone is positive or negative for stocks.
2. Claude analysis (optional, needs an Anthropic API key): a short, reasoned impact note.
Neither is investment advice.
"""
from __future__ import annotations

import json
import re

from . import config as C


def _has(text: str, kw: str) -> bool:
    kw = kw.strip().lower()
    tail = r"(?:s|es|ed|d|ing)?" if kw[-1:].isalpha() else ""   # jump → jumps/jumped/jumping
    return re.search(r"(?<![a-z0-9])" + re.escape(kw) + tail + r"(?![a-z0-9])", text) is not None


def _count(text: str, words: list[str]) -> int:
    return sum(1 for w in words if _has(text, w))


def analyze_rules(article: dict) -> dict:
    text = f" {article.get('title', '')} . {article.get('summary', '')} ".lower()
    title = f" {article.get('title', '')} ".lower()

    # where is it about?
    regions = [r for r, kws in C.REGION_KEYWORDS.items() if any(_has(text, k) for k in kws)]
    if not regions:
        regions = [article.get("region", "Global")]

    # tone for equities
    pos, neg = _count(text, C.POSITIVE_WORDS), _count(text, C.NEGATIVE_WORDS)
    tone = 1 if pos > neg else -1 if neg > pos else 0

    # themes and sectors
    themes, sectors = [], {}
    for rule in C.SECTOR_RULES:
        if not any(_has(text, k) for k in rule["keywords"]):
            continue
        themes.append(rule["name"])
        eff = dict(rule["sectors"])
        hint = C.DIRECTION_HINTS.get(rule["name"])
        if hint:
            up, down = _count(text, hint["up"]), _count(text, hint["down"])
            if up > down:
                eff.update(hint["if_up"])
            elif down > up:
                eff.update(hint["if_down"])
        for s, v in eff.items():
            if v == 0 and tone and rule["name"] not in C.DIRECTION_HINTS:
                v = tone
            sectors[s] = v if s not in sectors else (sectors[s] or v)

    markets = []
    for r in regions:
        idx = C.REGION_MAIN_INDEX.get(r)
        if idx and idx not in markets:
            markets.append(idx)

    for th in themes:  # commodity / currency themes also point at that asset
        for asset in C.THEME_ASSETS.get(th, []):
            if asset not in markets:
                markets.append(asset)

    # importance: themes hit + how many outlets carry it + market words in the headline
    score = len(themes) * 2 + min(len(article.get("also_in", [])), 6) + 2 * _count(title, [
        "stocks", "shares", "market", "sensex", "nifty", "dow", "nasdaq", "s&p", "index", "oil", "gold", "rupee",
        "fed", "rbi", "ecb", "rate", "inflation", "gdp", "tariff"])
    level = "High" if score >= 8 else "Medium" if score >= 4 else "Low"

    return {
        "source": "rules",
        "regions": regions,
        "markets": markets,
        "themes": themes,
        "sectors": [{"name": s, "effect": v} for s, v in sectors.items()],
        "tone": tone,
        "score": score,
        "level": level,
        "summary": _explain(themes, tone, regions),
    }


def _explain(themes, tone, regions) -> str:
    if not themes:
        return "No direct market theme detected – general news."
    t = {1: "positive", -1: "negative", 0: "mixed / unclear"}[tone]
    return f"Touches {', '.join(themes)} in {', '.join(regions)}. Overall tone for stocks looks {t}."


PROMPT = """You are a careful markets analyst. Read the news below and explain its likely impact on share markets.
Return ONLY valid JSON with this shape:
{{"headline_view": "one sentence on why this matters (or doesn't) for markets",
  "markets": [{{"name": "index or asset, e.g. Nifty 50, S&P 500, Brent crude, USD/INR", "direction": "up|down|mixed", "why": "short reason"}}],
  "sectors": [{{"name": "sector", "direction": "up|down|mixed", "why": "short reason"}}],
  "stocks_to_watch": ["company names only if clearly named or obviously affected"],
  "time_horizon": "intraday|days|weeks|long term",
  "confidence": "low|medium|high",
  "what_to_watch_next": "one sentence"}}
Keep it to at most 4 markets and 5 sectors. If the story has little market relevance, say so and keep lists short.

TITLE: {title}
SOURCE: {publisher}  PUBLISHED (UTC): {published}
TEXT: {body}
"""


def analyze_claude(article: dict, body: str, api_key: str, model: str = C.DEFAULT_CLAUDE_MODEL) -> dict:
    """Ask Claude for an impact view. Raises on API errors (the app shows a friendly message)."""
    import anthropic

    client = anthropic.Anthropic(api_key=api_key)
    msg = client.messages.create(
        model=model,
        max_tokens=900,
        messages=[{"role": "user", "content": PROMPT.format(
            title=article["title"], publisher=article.get("publisher", ""), published=article.get("published", ""),
            body=(body or article.get("summary", ""))[:6000])}],
    )
    text = "".join(getattr(b, "text", "") for b in msg.content)
    return parse_json(text) | {"source": "claude", "model": model}


def parse_json(text: str) -> dict:
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return {"headline_view": text.strip()[:500]}
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return {"headline_view": text.strip()[:500]}
